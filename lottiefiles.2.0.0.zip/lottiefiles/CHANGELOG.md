# @lottiefiles/plugin-wordpress

## 2.0.0

### Major Changes

- e457234: Major workflow update

## 1.1.0

### Minor Changes

- f388d75: Fixed Block Movement/ Drag & Drop issue
- 4521d07: fixed Import from media library

## 1.0.5

### Patch Changes

- UI fixes, copy fixes

## 1.0.4

### Patch Changes

- Hit counter fix
- Interactivity scroll fix
- CSS Namespace population fix
- Only load CSS where relevant

## 1.0.3

### Patch Changes

- Upload JSON fixes

## 1.0.2

### Patch Changes

- Update common php function names to be unique to avoid namespace clashes

## 1.0.1

### Patch Changes

- Documentation updates for readme and dev readme
- Updates for WordPress SVN listing

## 1.0.0

### Major Changes

- First stable release
