/**
 * Copyright 2022 Design Barn Inc.
 */

export enum SettingsKind {
  ERROR = 'ERROR',
  LOADING = 'LOADING',
  UPDATE_SETTINGS = 'UPDATE_SETTINGS',
}
