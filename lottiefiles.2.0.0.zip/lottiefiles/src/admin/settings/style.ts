/**
 * Copyright 2022 Design Barn Inc.
 */

// eslint-disable-next-line import/no-unassigned-import
import './admin.scss';
