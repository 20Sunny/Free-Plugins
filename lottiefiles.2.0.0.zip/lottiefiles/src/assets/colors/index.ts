/**
 * Copyright 2022 Design Barn Inc.
 */

export const color = {
  centerBorder: '#DAE1E7',
  black: '#1e1e1e',
  activeColor: '#007CBA',
  bgColor: '#FAFAFA',
  white: 'white',
  $teal300: '#00c1a2',
};
