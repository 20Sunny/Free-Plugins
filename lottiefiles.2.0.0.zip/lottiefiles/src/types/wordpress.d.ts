/**
 * Copyright 2022 Design Barn Inc.
 */

declare global {
  const wp: unknown;
}
